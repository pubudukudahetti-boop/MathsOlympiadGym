# Maths Olympiad Gym Android

This Android Studio project packages the supplied HTML game as a WebView app. The game runs locally and stores scores with WebView localStorage. Google Fonts may require connectivity; fallback fonts are provided.

## Build APK
1. Open this folder in Android Studio (with Android SDK 35 and JDK 17 installed).
2. Allow Gradle sync to finish.
3. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Find the APK at `app/build/outputs/apk/debug/app-debug.apk`.
5. Transfer the APK to your Android phone and install it (allow installation from that source if prompted).

Note: This project has not been compiled or device-tested in this environment.
